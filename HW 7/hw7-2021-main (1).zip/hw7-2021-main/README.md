# hw7-2022
Starter Code for HW7 - JavaScript basics with Video
